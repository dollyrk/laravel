<?php

namespace App\Http\Controllers;
use App\patient;
use App\doctor;
use App\complaint;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Redirect,Response,Validator;
use Session;

class saveController extends Controller
{

    
    public function loadLogin(){
        return  view('login');
                    
        
    }

    public function loadDash(){
        $data['list'] = null;
        $data['type'] = session()->get('type');
        $data['content'] = 'home';
        return  view('new',$data);
                    
        
    }

    public function profile(Request $request){
       
        $email = $request->session()->get('email');
        $data['list'] = DB::table('patients')->where('patient_email', $email)->first();
        $data['content']= 'profile';
        $data['type']= 'view';
        return  view('new',$data);
                    
        
    }

    public function findDoc(){
        $data['list'] = DB::table('doctors')->get();
        $data['content']= 'doc_list';
        $data['type']= 'view';
        return view('new',$data);
    }
  //compalaint page part
    public function complaint(){
        $data['list'] = null;
        $data['content']= 'complaint';
        $data['type']= null;
        return  view('new',$data);
                    
        
    }

    //compalaint save
    
    public function saveComplaint(Request $request) {
       
    
        try{
            DB::beginTransaction();
        $complaintType = $request->request->get('comp_type');
        $complaint = $request->request->get('complaint');
        
        DB::table('complaints')->insert(
                ['complaint_type' => $complaintType, 'complaint_details' =>$complaint,]
        );
         DB::commit();
         return Redirect::to("dash")->withSuccess('Great! You have Successfully lodge a complaint');
         //return view('login')->with('message', 'User is created!');
       
    
        } catch (Exception $ex) {
             return response('Something is wrong while inserting');
            DB::rollBack();
        }
    
    }
    

   //login page
    public function logindash(Request $request){

        $type = $request->request->get('type');
        $email = $request->request->get('email');
        $password = $request->request->get('password');
        
        if($type == "patient"){
        $check_user = DB::table('patients')->where('patient_email', $request->request->get('email'))->first();
        $old_pass = $check_user->patient_password;
        }else if($type == "doctor"){

        $check_user = DB::table('doctors')->where('doc_email', $request->request->get('email'))->first();
        $old_pass = $check_user->doc_password;

        }else{
        $check_user = DB::table('clinics')->where('clinic_email', $request->request->get('email'))->first();
        $old_pass = $check_user->clinic_password;
        }
        $check_user = DB::table('patients')->where('patient_email', $request->request->get('email'))->first();
        
        if(!Hash::check($password,$old_pass)){

            return Redirect::to("/")->withSuccess('Oppes! You have entered invalid credentials');

         }else{
            $request->session()->put('email',$email);
            $request->session()->put('type',$type);
           return redirect()->intended('dash');
            
         }

    }
    public function loadReg(){
        return  view('registration');
                    
        
    }
    

/* Save Registration Details */
public function saveRegistrationDetails(Request $request) {

    //patient part
    if($request->request->get('type') == "patient"){
    $check_duplicate = DB::table('patients')->where('patient_email', $request->request->get('email'))->first();
    if($check_duplicate){
    echo('email is already exist');
    }else{

    try{
        DB::beginTransaction();
    $patientName = $request->request->get('name');
    $patientAddress = $request->request->get('address');
    $patientPhone = $request->request->get('phone');
    $patientEmail = $request->request->get('email');
    $patientPassword = $request->request->get('password');
    
    $hashedPassword = Hash::make($patientPassword);
    
    
    DB::table('patients')->insert(
            ['patient_name' => $patientName, 'patient_address' =>$patientAddress,
                'patient_phone' =>$patientPhone,'patient_email' =>$patientEmail,'patient_password' =>$hashedPassword]
    );
     DB::commit();
     $request->session()->put('email', $patientEmail);
     $request->session()->put('type',$request->request->get('type'));
     return Redirect::to("/dash")->withSuccess('Great! You have Successfully loggedin');
     //return view('login')->with('message', 'User is created!');
   

    } catch (Exception $ex) {
         return response('Something is wrong while inserting');
        DB::rollBack();
    }
  }
  //doctor part
 }else if($request->request->get('type') == "doctor"){


    $check_duplicate = DB::table('doctors')->where('doc_email', $request->request->get('email'))->first();
    if($check_duplicate){
    echo('email is already exist');
    }else{

    try{
        DB::beginTransaction();
    $docName = $request->request->get('name');
    $docAddress = $request->request->get('address');
    $docPhone = $request->request->get('phone');
    $docEmail = $request->request->get('email');
    $docPassword = $request->request->get('password');
    $area = $request->request->get('area_speciality');
    
    
    $hashedPassword = Hash::make($docPassword);
    
    
    DB::table('doctors')->insert(
            ['doc_name' => $docName, 'doc_address' =>$docAddress,
                'doc_phone' =>$docPhone,'doc_email' =>$docEmail,'doc_password' =>$hashedPassword,'doc_area_speciality' =>$area]
    );
     DB::commit();
     $request->session()->put('email',$docEmail);
     $request->session()->put('type',$request->request->get('type'));
     return Redirect::to("/dash")->withSuccess('Great! You have Successfully loggedin');
     

    } catch (Exception $ex) {
         return response('Something is wrong while inserting');
        DB::rollBack();
    }
  }
    //clinic part
 }else{

    $check_duplicate = DB::table('clinics')->where('clinic_email', $request->request->get('email'))->first();
    if($check_duplicate){
    echo('email is already exist');
    }else{

    try{
        DB::beginTransaction();
    $clinicName = $request->request->get('name');
    $clinicAddress = $request->request->get('address');
    $clinicPhone = $request->request->get('phone');
    $clinicEmail = $request->request->get('email');
    $clinicPassword = $request->request->get('password');
    
    $hashedPassword = Hash::make($clinicPassword);
    
    
    DB::table('clinics')->insert(
            ['clinic_name' => $clinicName, 'clinic_address' =>$clinicAddress,
                'clinic_phone' =>$clinicPhone,'clinic_email' =>$clinicEmail,'clinic_password' =>$hashedPassword]
    );
     DB::commit();
     $request->session()->put('email',$clinicEmail);
     $request->session()->put('type',$request->request->get('type'));
     return Redirect::to("/dash")->withSuccess('Great! You have Successfully loggedin');
     //return view('login')->with('message', 'User is created!');
   

    } catch (Exception $ex) {
         return response('Something is wrong while inserting');
        DB::rollBack();
    }
  }

 }

}


//update Patient page

public function updatePatient() {
    $data['list'] = DB::table('patients')->get();
    $data['content']= 'profile';
    $data['type']= 'update';
    return  view('new',$data);
}

public function patientView($id) {
    $data['list'] = DB::table('patients')->where('id', $id)->first();
    $data['content']= 'view_profile';
    $data['type']= 'edit';
    return  view('new',$data);
}

//post update function

public function patientEdit(Request $request,$id) {
    try{
        DB::beginTransaction();
    $patientName = $request->request->get('name');
    $patientAddress = $request->request->get('address');
    $patientPhone = $request->request->get('phone');
    $patientEmail = $request->request->get('email');
    $patientDiag = $request->request->get('diag');
    
    DB::table('patients')->where('id',$id)->update(
            ['patient_name' => $patientName, 'patient_address' =>$patientAddress,
                'patient_phone' =>$patientPhone,'patient_email' =>$patientEmail,'patient_diagnose' =>$patientDiag]
    );
     DB::commit();
     return Redirect::to("/update_patient")->withSuccess('Great! You have Successfully Upadated');
    

    } catch (Exception $ex) {
         return response('Something is wrong while updating');
        DB::rollBack();
    }
  
}

//view complaint part

public function viewComplaint(){
    $data['list'] = DB::table('complaints')->get();
    $data['content']= 'complaint_list';
    $data['type']= 'view';
    return view('new',$data);
}
//solution page

public function solution($id) {
    $data['list'] = DB::table('complaints')->where('id', $id)->first();
    $data['content']= 'view_profile';
    $data['type']= 'solution';
    return  view('new',$data);
}

//upadte solution



public function updateSolution(Request $request,$id) {
    try{
        DB::beginTransaction();
        $complaintType = $request->request->get('comp_type');
        $complaint = $request->request->get('complaint');
        $solution = $request->request->get('solution');
    
    DB::table('complaints')->where('id',$id)->update(
            ['complaint_type' => $complaintType, 'complaint_details' =>$complaint,
                'solution' =>$solution]
    );
     DB::commit();
     return Redirect::to("/view_complaint")->withSuccess('Great! You have Successfully Upadated');
    

    } catch (Exception $ex) {
         return response('Something is wrong while updating');
        DB::rollBack();
    }
  
}

public function logout() {
    Session::flush();
    //Auth::logout();
    return Redirect('/');
}
    
}
