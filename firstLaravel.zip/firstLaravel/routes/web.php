<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'saveController@loadLogin');
Route::get('/dash','saveController@loadDash');
Route::get('/reg','saveController@loadReg');
Route::post('/save-reg-details','saveController@saveRegistrationDetails');
Route::post('/login-dash','saveController@logindash');
Route::get('/logout','saveController@logout');
Route::get('/doc_list','saveController@findDoc');
Route::get('/create_complaint','saveController@complaint');
Route::post('/add_complint','saveController@saveComplaint');
Route::get('/profile','saveController@profile');
Route::get('/update_patient','saveController@updatePatient');
Route::get('/edit/{id}','saveController@patientView');
Route::post('/update_patient/{id}','saveController@patientEdit');
Route::get('/view_complaint','saveController@viewComplaint');
Route::get('/solution/{id}','saveController@solution');
Route::post('/update_solution/{id}','saveController@updateSolution');










