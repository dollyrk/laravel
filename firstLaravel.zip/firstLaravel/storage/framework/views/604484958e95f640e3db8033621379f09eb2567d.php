<table class="table">
    <tr>
        <td>Incident Name</td>
        <td> 
            <input type="text" name="fname"/>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <button type="button" class="btn-primary">Search</button>
        </td>
    </tr>
</table>