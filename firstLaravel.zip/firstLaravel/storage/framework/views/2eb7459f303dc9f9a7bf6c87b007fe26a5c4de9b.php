 


<!-- Modal -->
<!-- <div class="modal fade" id="myModal" role="dialog"> -->
<div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header" style="background-color: #00ff3717;">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title text-center">Incident Details</h4>
        </div>
        <div class="modal-body">
            <table class="table">
                <tr>
                    <td>Incident Name</td>
                    <td><?php echo e($inc->incident_name); ?></td>
                </tr>
                <tr>
                    <td>Incident Media</td>
                    <td>
                        <?php $mediaName = $media ?>
                        <?php if($media == ''): ?>
                        <img src="<?php echo e(asset('/images/profile.png')); ?>" style="height: 50px;width:50px;"/>
                        <?php else: ?>
                        <img src="<?php echo e(asset('/storage/'.$mediaName)); ?>" style="height: 50px;width:50px;"/>
                        <?php endif; ?>

                    </td>
                </tr>
                <tr>
                    <td>Description</td>
                    <td><?php echo e($inc->incident_description); ?></td>
                </tr>
                <tr>
                    <td>Status</td>
                    <?php $statusId =$status?>
                    <?php if($status==''): ?>
                    <td></td>
                    <?php else: ?>
                    <td><?php echo e($statusId->status_name); ?></td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Label</td>
                    <td><?php echo e($inc->label); ?></td>
                </tr>
                <tr>
                    <td>Added Name</td>
                    <?php $addedName = $member?>
                    <td><?php echo e($addedName->member_name); ?></td>
                </tr>
                <tr>
                    <td>Create Date</td>
                    <td><?php echo e((new \DateTime($inc->create_date))->format('d-m-Y')); ?></td>
                </tr>
                <tr>
                    <td>End Date</td>
                    <td><?php echo e((new \DateTime($inc->end_date))->format('d-m-Y')); ?></td>
                </tr>
                <tr>
                    <td>Priority</td>
                    <?php $priorityName = $priority?>
                    <?php if($priority==''): ?>
                    <td></td>
                    <?php else: ?>
                    <td><?php echo e($priority->priority_name); ?></td>
                    <?php endif; ?>
                </tr>
                <tr>
                    <td>Location</td>
                    <td><?php echo e($inc->location); ?></td>
                </tr>
            </table>

        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>
</div>
