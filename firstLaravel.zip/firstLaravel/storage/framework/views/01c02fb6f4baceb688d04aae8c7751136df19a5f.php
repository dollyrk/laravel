<div class="container" style="width: 100%;">
  <div id="myCarousel" class="carousel slide" data-ride="carousel" style="height: 60%;width: 80%;">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$mediafile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li data-target="#myCarousel" data-slide-to="<?php echo e($key+1); ?>"></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!--      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>-->
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" >
      <div class="item active">
          <?php $firstFilename = $media[0]->original_filename?>
          <img src="<?php echo e(asset('/storage/'.$firstFilename)); ?>"/>
      </div>
        <?php $__currentLoopData = $media; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mediafile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $filename = $mediafile->original_filename ?>
        <div class="item">
    <img src="<?php echo e(asset('/storage/'.$filename)); ?>" />
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>