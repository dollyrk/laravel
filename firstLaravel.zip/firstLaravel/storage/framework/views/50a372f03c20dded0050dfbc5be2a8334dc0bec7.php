

<div class="row">
    <div class="col-md-6">
    <table id="patient_list" class="table table-bordered table-striped" >
    <tr style="background-color: #737394;color: #fff;">
        <?php if($type == 'update') {?>
        <th>Sl No.</th>
        <?php } ?>
        <th>Patient Name</th>
        <th>Patient Email</th>
        <th>Patient Phone</th>
        <th>Patient Address</th>
        <th>Diagnosed</th>
        <?php if($type == 'update') {?>
        <th>Action</th>
        <?php } ?>
        
    </tr>
    <?php if($type == 'view') {?>
        <tr>
        <td><?php echo e($list->patient_name); ?></td>
        <td><?php echo e($list->patient_email); ?></td>
        <td><?php echo e($list->patient_phone); ?></td>
        <td><?php echo e($list->patient_address); ?></td>
        <td><?php echo e($list->patient_diagnose); ?></td>
    </tr>
    <?php }else if($type == 'update') {?>
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr class="tableRow">
        <td><?php echo e($key + 1); ?></td>
        <td><?php echo e($lt->patient_name); ?></td>
        <td><?php echo e($lt->patient_email); ?></td>
        <td><?php echo e($lt->patient_phone); ?></td>
        <td><?php echo e($lt->patient_address); ?></td>
        <td><?php echo e($lt->patient_diagnose); ?></td>
        <td><a type="button" class="btn btn-primary" href="<?= url('/edit/'.$lt->id); ?>">Update</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php } ?>
     
   </table>    
    </div>
</div>
