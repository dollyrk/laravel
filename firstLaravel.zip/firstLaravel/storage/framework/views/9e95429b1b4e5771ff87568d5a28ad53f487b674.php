<!-- Modal -->
<!-- <div class="modal fade" id="myModal" role="dialog"> -->
<div class="modal-dialog modal-lg">
    <div class="modal-content">
        <div class="modal-header" style="background-color: #00ff3717;">
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4 class="modal-title text-center">Add New Member</h4>
        </div>
        <div class="modal-body">
            <form id="member-form" action="<?php echo e(url('/save-member')); ?>" method="POST">
                <?php echo e(csrf_field()); ?>

                <center>
                    <div class="form-group">
                        <label for="memberName">Member Name</label>
                        <input type="text" class="form-control custom-input" id="memberName" name="memberName">
                        <label id="nameErr" style="color: red;display: none;">Please enter member name;</label>
                    </div>

                    <button type="submit" class="btn btn-primary">Save</button>    
                </center>

            </form>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
    </div>
</div>
</div>