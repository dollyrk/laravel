<form id="incident-form" action="<?php echo e(url('/save-incident-details')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <table class="table">
        <tr>
            <td>Incident Name</td>
            <td> 
                <input id="incidentName" type="text" name="name" class="form-control custom-input"/>
                <label id="nameErr" style="color: red;display: none;">Please enter incident name;</label>
            </td>
        </tr>
        <tr>
            <td>Incident Media</td>
            <td>
                <input type="file" name="media" class="form-control-file custom-input" style="width: 250px;"/>
            </td>
        </tr>
        <tr>
            <td>Description</td>
            <td>
                <textarea name="description" class="form-control custom-input"></textarea>
            </td>
        </tr>
        <tr>
            <td>Severity</td>
            <td>
                <select name="satus" class="form-control custom-input" id="" style="width: 200px;">
                    <option value="">Select Severity</option>
                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($stat->id); ?>"><?php echo e($stat->status_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Label</td>

            <td>
                <input type="text" class="form-control custom-input" name="label"/>
            </td>
        </tr>
        <tr>
            <td>Added Name</td>

            <td>
                <select name="member" class="form-control custom-input" id="addedName" style="width: 200px;">
                    <option value="">Select Added Name</option>
                    <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $membr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($membr->id); ?>"><?php echo e($membr->member_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label id="memberErr" style="color: red;display: none;">Please select added name;</label>
            </td>
        </tr>
        <tr>
            <td>Create Date</td>

            <td>
                <input type="date" name="createDate" class="form-control custom-input"/>
            </td>
        </tr>
        <tr>
            <td>End Date</td>

            <td>
                <input type="date" name="endDate" class="form-control custom-input"/>
            </td>
        </tr>
        <tr>
            <td>Priority</td>
            <td>
                <select name="priority" class="form-control custom-input" id="" style="width: 200px;">
                    <option value="">Select Priority</option>
                    <?php $__currentLoopData = $priority; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($prio->id); ?>"><?php echo e($prio->priority_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>Location</td>

            <td>
                <textarea name="location" class="form-control custom-input"></textarea>
            </td>
        </tr>
        <tr>
            <td colspan="2" >
                <button class="btn-primary" type="submit" >Save</button>
            </td>
        </tr>
    </table>
</form>