<!DOCTYPE html>

<head>

    <title>HMS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">

       <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" media="screen">
        <link href="<?php echo e(asset('DataTables/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" media="screen">
        <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" media="screen">
</head>
<style type="text/css">
    .error{
        color: red;
    }
</style>
<body id="top" >
  
<div class="login">
    <div class="container">
        <div class="row login-box">
            <div class="col-lg-12 col-md-12 bg-color-8 ">
                <div class="form-section">
                   
                    <div class="login-inner-form">
                   
                            <form id="patient-form" action="<?php echo e(url('/save-reg-details')); ?>" method="POST" enctype="multipart/form-data"  class="form-signin">
                                <?php echo e(csrf_field()); ?>


                                <div >
                                 <p style="font-weight: bold;font-size: 25px;color: #0267e3;text-align:center">REGISTRATION FORM</p>
                                </div>
                                <table class="table">
                                <tr>
                                <td>Type</td>
                                       <td> 
                                            <select id="type" class="form-control custom-input"  name="type" >
                                            <option selected="selected" value="" >Select Type</option>
                                            <option value="doctor" >Doctor</option>
                                            <option value="patient" >Patient</option>
                                            <option value="clinic" >Clinic</option>
                                            </select> 
                                       </td> 
                                </tr>
                                    <tr>
                                        <td>Name</td>
                                        <td> 
                                            <input type="text" id="name"  name="name" class="form-control custom-input" required/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Address</td>
                                        <td>
                                        <input type="text" id="address"  name="address" class="form-control custom-input"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Phone</td>
                                        <td>
                                        <input type="text" id="phone"  name="phone" class="form-control custom-input"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Email</td>
                                        <td>
                                        <input type="email" id="email"  name="email" class="form-control custom-input" autocomplete="off" required/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>If Doctor?Area Of Speciality</td>
                                        <td>
                                        <input type="text" id="area_speciality"  name="area_speciality" class="form-control custom-input"/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Password</td>
                                        <td>
                                        <input type="password" id="password"  name="password" class="form-control custom-input" autocomplete="off"  required/>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Confirm Password</td>
                                        <td>
                                        <input type="password" id="conf_password"  name="conf_password" class="form-control custom-input" required  />
                                        <span id='message'></span>
                                    </td>
                                    </tr>
                                
                                    <tr>
                                        <td colspan="2" >
                                            <button class="btn-primary" id="btnSubmit" type="submit" >Save</button>
                                        </td>
                                    </tr>
                                </table>
                            </form>

                            
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</html>



<script src="<?php echo e(asset('js/jquery.js')); ?>" type="text/javascript"></script>
<script>
  $('#password, #conf_password').on('keyup', function () {
  if ($('#password').val() == $('#conf_password').val()) {
    $("#btnSubmit").prop("disabled", false);
    $('#message').html(' ');
    
  } else if($('#password').val() != $('#conf_password').val()){ 
    $('#message').html('Not Matching').css('color', 'red');
    $("#btnSubmit").prop("disabled", true);
}
  });
</script>