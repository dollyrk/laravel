

<div class="row">
    <div class="col-md-6">
    <table id="compalint_list" class="table table-bordered table-striped" >
    <tr style="background-color: #737394;color: #fff;">
        <th>Sl</th>
        <th>Complaint Type</th>
        <th>Complaint</th>
        <th>Action</th>
        
    </tr>
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$complaint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
        <tr>
        <td><?php echo e($key+1); ?></td>
        <td><?php echo e($complaint->complaint_type); ?></td>
        <td><?php echo e($complaint->complaint_details); ?></td>
        <td><a type="button" class="btn btn-success" href="<?= url('/solution/'.$complaint->id); ?>">Solution</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
   </table>    
    </div>
    <!-- <div class="col-md-4" id='member-area'>
        <button id='newMember' type="button" class="btn btn-primary" data-url="" >Add New Member</button>
    </div> -->
</div>
<script src="<?php echo e(asset('js/jquery.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('DataTables/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('DataTables/js/dataTables.bootstrap.min.js')); ?>"></script>
<script type="text/javascript">
  $('#compalint_list').DataTable( {
                "dom": 'Bfrtip',
               "buttons": [
                ],
               "paging": true,
               "lengthChange": false,
               "searching": true,
               "ordering": true,
               "info": true,
               "autoWidth": true,
               "order": [[ 0, "dsc" ]],
               'aoColumnDefs': [{
                 'bSortable': true,
                 'aTargets': -1,         
              }]

});

</script>