<form id="patient-form" action="<?php echo e(url('/save-patient-details')); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <table class="table">
        <tr>
            <td>Name</td>
            <td> 
                <input type="text" id="name"  name="name" class="form-control custom-input"/>
                <label id="nameErr" style="color: red;display: none;">Please enter incident name;</label>
            </td>
        </tr>
        <tr>
            <td>Address</td>
            <td>
            <input type="text" id="address"  name="address" class="form-control custom-input"/>
            </td>
        </tr>
        <tr>
            <td>Phone</td>
            <td>
            <input type="text" id="phone"  name="phone" class="form-control custom-input"/>
            </td>
        </tr>
        <tr>
            <td>Email</td>
            <td>
            <input type="email" id="email"  name="email" class="form-control custom-input"/>
            </td>
        </tr>
        <tr>
            <td>Password</td>
            <td>
            <input type="password" id="password"  name="password" class="form-control custom-input" onclick="login()"/>
            </td>
        </tr>
        <tr>
            <td>Confirm Password</td>
            <td>
            <input type="password" id="conf_password"  name="conf_password" class="form-control custom-input" onclick="login()"/>
            </td>
        </tr>
      
        <tr>
            <td colspan="2" >
                <button class="btn-primary" type="submit" >Save</button>
            </td>
        </tr>
    </table>
</form>



<script src="<?php echo e(asset('js/jquery.js')); ?>" type="text/javascript"></script>
<script>
   
     $(document).ready(function(){            
   
     });

     function login() {
        
         var password = $("#password").val()
         var conf_pass = $("#conf_password").val()
         var pswlen = password.length;
         
            if (password == conf_pass) {
               
             }
             else {
                 //alert('Password not matching');
             }

        

     }
    
</script>