<div class="row">
    <div class="col-md-6">
    <table class="table" id="">
    <tr style="background-color: #737394;color: #fff;">
        <th>Member ID</th>
        <th>Member Name</th>
    </tr>
    <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="tableRow">
        <td><?php echo e($list->id); ?></td>
        <td><?php echo e($list->member_name); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>    
    </div>
    <div class="col-md-4" id='member-area'>
        <button id='newMember' type="button" class="btn btn-primary" data-url="<?php echo e(url('add-new-member')); ?>" >Add New Member</button>
    </div>
</div>

