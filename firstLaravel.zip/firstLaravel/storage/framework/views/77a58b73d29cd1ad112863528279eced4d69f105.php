<?php if($type == 'solution'){ ?>
    <form id="patient-form" action="<?php echo e(url('/update_solution/'.$list->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <table class="table">
    <tr>
            <td>Complaint Type</td>
            <td> 
                <input type="text" id="comp_type"  name="comp_type" value="<?php echo e($list->complaint_type); ?>" class="form-control custom-input"/>
            </td>
        </tr>
        <tr>
            <td>Compalaint</td>
            <td>
            <textarea id="complaint" name="complaint" row="10" class="form-control custom-input"><?php echo e($list->complaint_details); ?></textarea>
            </td>
        </tr>
        <tr>
            <td>Solution</td>
            <td>
            <textarea id="solution" name="solution" row="10" class="form-control custom-input"><?php echo e($list->solution); ?></textarea>
            </td>
        </tr>
    <?php }else if($type =='edit' ) {?>
<form id="patient-form" action="<?php echo e(url('/update_patient/'.$list->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <table class="table">

       
        <tr>
            <td>Name</td>
            <td> 
                <input type="text" id="name"  name="name" value="<?php echo e($list->patient_name); ?>" class="form-control custom-input"/>
            </td>
        </tr>
        <tr>
            <td>Address</td>
            <td>
            <input type="text" id="address"  name="address" value="<?php echo e($list->patient_address); ?>" class="form-control custom-input"/>
            </td>
        </tr>
        <tr>
            <td>Phone</td>
            <td>
            <input type="text" id="phone"  name="phone"  value="<?php echo e($list->patient_phone); ?>" class="form-control custom-input"/>
            </td>
        </tr>
        <tr>
            <td>Email</td>
            <td>
            <input type="email" id="email"  name="email" value="<?php echo e($list->patient_email); ?>" class="form-control custom-input"/>
            </td>
        </tr>
        <tr>
            <td>Diagnose</td>
            <td>
            <input type="text" id="diag"  name="diag" value="<?php echo e($list->patient_diagnose); ?>" class="form-control custom-input"/>
            </td>
        </tr>
       
      <?php } ?>
        <tr>
            <td colspan="2" >
                <button class="btn-primary" type="submit" >Save</button>
            </td>
        </tr>
    </table>
</form>
