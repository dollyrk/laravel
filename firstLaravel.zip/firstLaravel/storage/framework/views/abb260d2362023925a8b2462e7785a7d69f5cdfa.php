<form id="doctor-form" action="<?php echo e(url('/add_complint')); ?>" method="POST" enctype="multipart/form-data">
<?php echo e(csrf_field()); ?>

    <table class="table">
        <tr>
            <td>Complaint Type</td>
            <td> 
                <input type="text" id="comp_type"  name="comp_type" class="form-control custom-input"/>
            </td>
        </tr>
        <tr>
            
        <tr>
            <td>Complaint</td>
            <td>
            <textarea id="complaint" name="complaint" row="10" class="form-control custom-input"></textarea>
            </td>
        </tr>
      
        <tr>
            <td colspan="2" >
                <button class="btn-primary" type="submit" >Save</button>
            </td>
        </tr>
    </table>
</form>