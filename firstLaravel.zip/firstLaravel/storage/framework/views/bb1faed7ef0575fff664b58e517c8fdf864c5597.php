<!DOCTYPE html>

<head>

    <title>HMS</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">

       <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" media="screen">
        <link href="<?php echo e(asset('DataTables/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" media="screen">
        <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" media="screen">
</head>
<style type="text/css">
    .error{
        color: red;
    }
</style>
<body id="top" >
  
<div class="login">
    <div class="container">
        <div class="row login-box">
            <div class="col-lg-12 col-md-12 bg-color-8 ">
                <div class="form-section">
                   
                    <div class="login-inner-form">
                   
                        <form id="login-form" action="<?php echo e(url('/login-dash')); ?>" method="POST" enctype="multipart/form-data" class="form-signin">
                        <?php echo e(csrf_field()); ?>

                           <div >
                           <p style="font-weight: bold;font-size: 25px;color: #0267e3;text-align:center">HMS</p>
                            </div>
                           <div class="form-group form-box">
                            <select id="type" class="form-control custom-input" name="type" required>
                                <option selected="selected" value="" >Select Type</option>
                                <option value="doctor" >Doctor</option>
                                <option value="patient" >Patient</option>
                                <option value="clinic" >Clinic</option>
                            </select>   
                            </div>
                            <div class="form-group form-box">
                                <input type="email" name="email" class="form-control custom-input" placeholder="Email Address" required>
                                <i class="fa fa-envelope"></i>
                            </div>
                            <div class="form-group form-box">
                                <input type="password" name="password" class="form-control custom-input" placeholder="Password" required>
                                <i class="fa fa-lock"></i>
                            </div>
                             <div class="form-group mb-0">
                                <button type="submit" class="btn-md" value="LOGIN">LOGIN</button>
                            </div>
                            <div >
                                Not a user?<a href="<?= url('/reg'); ?>">Sign up</a>
                            </div>
                        </form>
                            
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</html>
