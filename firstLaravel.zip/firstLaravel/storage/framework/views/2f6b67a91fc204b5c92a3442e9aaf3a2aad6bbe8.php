<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>HMS</title>
        <!-- Bootstrap Core CSS -->
        <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet" media="screen">
        <link href="<?php echo e(asset('DataTables/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet" media="screen">
        <link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet" media="screen">
    </head>
    <body>
        <?php echo $__env->make('header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3 vertical-menu" style="height: 500px;">
                    <nav class="sidebar vertical-menu">
                <div id="left-menu" class="list-group left-menu" >
                    <a href="" class="list-group-item disabled">Hospital Management System</a>
                    <a href="<?php echo e(url('/dash')); ?>" class="list-group-item">Home</a>
                    <?php if( session()->get('type') == 'patient') {?>

                    <a id="" href="<?php echo e(url('/doc_list')); ?>"  class="list-group-item ">Find Doctor</a>
                    <a id="" href="<?= url('/create_complaint'); ?>"  class="list-group-item ">Complaint</a>
                    <a id="" href="<?= url('/profile'); ?>"  class="list-group-item ">Profile</a>

                    <?php }else if(session()->get('type') == 'doctor'){ ?>
                    <a id="" href="<?php echo e(url('/view_complaint')); ?>"  class="list-group-item ">View Complaint</a>
                    <!-- <a id="" href="<?= url('/solution'); ?>"  class="list-group-item ">Solution</a> -->
                    <?php }else{ ?>

                        <a id="" href="<?php echo e(url('/update_patient')); ?>"  class="list-group-item ">Update Patient</a>

                    <?php } ?>

                    <a id="" href="<?= url('/logout'); ?>"  class="list-group-item ">Logout</a>
                
                </div> 
                
                
                
                </nav>
                </div>
                <div class="col-md-9" style="min-height: 400px;">
                    <div class="row" style="background-color: #dcdce2;height: 40px;padding:5px;border: 1px solid #ccc;">
                        <span><strong>Dashboard</strong></span>
                    </div>
                    <div id="main-area" class="row" style="border: 1px solid #ddd;padding: 5px;">
                    <?php echo view($content,['list'=>$list,'type'=>$type]);?>
                     
                    </div>
                    
                </div>
            </div>
        </div>
            
        <div id="content-area" class="modal fade" role="dialog">
            
        </div>
   
        <?php echo $__env->make('footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </body>
</html>
