$(document).on('click', 'table#table-incident-list button#view', function (e) {
    var url = $(this).attr('data-url');
    $.ajax({
        url: url,
        dataType: 'json',
        type: 'GET',
        success: function (response) {
            if (response.success) {
                $('#content-area').empty().append(response.body);
                $('#content-area').modal('toggle');
            } else {
                $.alert('Sorry! Server is not responding.');
            }
        },
        error: function (ex) {
            console.log(e);
        }
    });
    return false;
});
$(document).on('click', 'div#left-menu a.menu-link', function (e) {
    var url = $(this).attr('data-url');
    $.ajax({
        url: url,
        dataType: 'json',
        type: 'GET',
        success: function (response) {
            if (response.success) {
                $('#main-area').empty().append(response.body);
            } else {
                $.alert('Sorry! Server is not responding.');
            }
        },
        error: function (ex) {

            console.log(e);
        }
    });
    return false;
});
$(document).on('click', '#top-menu li a.menu-link', function (e) {
    var url = $(this).attr('data-url');
    $.ajax({
        url: url,
        dataType: 'json',
        type: 'GET',
        success: function (response) {
            if (response.success) {
                $('#main-area').empty().append(response.body);
            } else {
                $.alert('Sorry! Server is not responding.');
            }
        },
        error: function (ex) {

            console.log(e);
        }
    });
    return false;
});
/*Sve Incident detaials*/
$(document).on('submit', 'form#incident-form', function (e) {
    var name = $('#incidentName').val();
    var addedName = $('#addedName').val();
    if (name == '') {
        $('#nameErr').show();
        return false;
    } else {
        $('#nameErr').hide();
    }
    if (addedName == '') {
        $('#memberErr').show();
        return false;
    } else {
        $('#memberErr').hide();
    }
    var url = $(this).attr('action');
    var formdata = new FormData($(this)[0]);
    var method = $(this).attr('method');
    $.ajax({
        url: url,
        data: formdata,
        dataType: 'json',
        async: false,
        type: method,
        processData: false,
        contentType: false,
        success: function (response) {
            if (response.success) {
                $('#main-area').empty().append(response.body);
            } else {
                $.alert('Sorry! Server is not responding.');
            }
        },
        error: function (e) {

            console.log(e);
        }
    });
});
/* Add new Member */
$(document).on('click', 'div#member-area button#newMember', function (e) {
    var url = $(this).attr('data-url');
    $.ajax({
        url: url,
        dataType: 'json',
        type: 'GET',
        success: function (response) {
            if (response.success) {
                $('#content-area').empty().append(response.body);
                $('#content-area').modal('toggle');
            } else {
                $.alert('Sorry! Server is not responding.');
            }
        },
        error: function (ex) {

            console.log(e);
        }
    });
    return false;
});
/* Save Member */
$(document).on('submit', 'form#member-form', function (e) {
    var name = $('#memberName').val();
    if (name == '') {
        $('#nameErr').show();
        return false;
    } else {
        $('#nameErr').hide();
    }
    var url = $(this).attr('action');
    var formdata = new FormData($(this)[0]);
    var method = $(this).attr('method');
    e.preventDefault();
    $.ajax({
        url: url,
        data: formdata,
        dataType: 'json',
        async: false,
        type: method,
        processData: false,
        contentType: false,
        success: function (response) {
            if (response.success) {
                $('#main-area').empty().append(response.body);
                $('#content-area').modal('toggle');
            } else {
                $.alert('Sorry! Server is not responding.');
            }
        },
        error: function (e) {

            console.log(e);
        }
    });
});