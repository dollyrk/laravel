

<div class="row">
    <div class="col-md-6">
    <table id="patient_list" class="table table-bordered table-striped" >
    <tr style="background-color: #737394;color: #fff;">
        <?php if($type == 'update') {?>
        <th>Sl No.</th>
        <?php } ?>
        <th>Patient Name</th>
        <th>Patient Email</th>
        <th>Patient Phone</th>
        <th>Patient Address</th>
        <th>Diagnosed</th>
        <?php if($type == 'update') {?>
        <th>Action</th>
        <?php } ?>
        
    </tr>
    <?php if($type == 'view') {?>
        <tr>
        <td>{{$list->patient_name}}</td>
        <td>{{$list->patient_email}}</td>
        <td>{{$list->patient_phone}}</td>
        <td>{{$list->patient_address}}</td>
        <td>{{$list->patient_diagnose}}</td>
    </tr>
    <?php }else if($type == 'update') {?>
        @foreach($list as $key=>$lt)
        <tr class="tableRow">
        <td>{{$key + 1}}</td>
        <td>{{$lt->patient_name}}</td>
        <td>{{$lt->patient_email}}</td>
        <td>{{$lt->patient_phone}}</td>
        <td>{{$lt->patient_address}}</td>
        <td>{{$lt->patient_diagnose}}</td>
        <td><a type="button" class="btn btn-primary" href="<?= url('/edit/'.$lt->id); ?>">Update</a></td>
    </tr>
    @endforeach
    <?php } ?>
     
   </table>    
    </div>
</div>
