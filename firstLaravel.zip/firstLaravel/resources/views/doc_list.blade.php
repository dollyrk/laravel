

<div class="row">
    <div class="col-md-6">
    <table id="doc_list" class="table table-bordered table-striped" >
    <tr style="background-color: #737394;color: #fff;">
        <th>Sl</th>
        <th>Doctor Name</th>
        <th>Doctor Phone</th>
        <th>Address</th>
        <th>Area Of Speciality</th>
        
    </tr>
    @foreach($list as $key=>$doc)
        
        <tr>
        <td>{{$key+1}}</td>
        <td>{{$doc->doc_name}}</td>
        <td>{{$doc->doc_phone}}</td>
        <td>{{$doc->doc_address}}</td>
        <td>{{$doc->doc_area_speciality}}</td>
    </tr>
    @endforeach
       
   </table>    
    </div>
    <!-- <div class="col-md-4" id='member-area'>
        <button id='newMember' type="button" class="btn btn-primary" data-url="" >Add New Member</button>
    </div> -->
</div>
<script src="{{asset('js/jquery.js')}}" type="text/javascript"></script>
<script src="{{asset('DataTables/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{asset('DataTables/js/dataTables.bootstrap.min.js')}}"></script>
<script type="text/javascript">
  $('#doc_list').DataTable( {
                "dom": 'Bfrtip',
               "buttons": [
                ],
               "paging": true,
               "lengthChange": false,
               "searching": true,
               "ordering": true,
               "info": true,
               "autoWidth": true,
               "order": [[ 0, "dsc" ]],
               'aoColumnDefs': [{
                 'bSortable': true,
                 'aTargets': -1,         
              }]

});

</script>