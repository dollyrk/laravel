
<?php if($type == 'patient'){ ?>
<div class="center">
Patient Portat
</div>
<?php }else if($type == "doctor"){ ?>
<div class="center">
Doctor Portal
</div>  
<?php }else{ ?>
<div class="center">
Clinic Portal
</div>
<?php } ?>
