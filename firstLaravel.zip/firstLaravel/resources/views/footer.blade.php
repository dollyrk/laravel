<footer class="footer">
    <div class="container-fluid" style="background-color: #000;">
        <p class="text-muted text-center" style="color: #fff;">Designed & Developed by:  Dolly</p>
    </div>
</footer>
<script src="{{asset('js/jquery.js')}}" type="text/javascript"></script>
<script src="{{asset('bootstrap/js/bootstrap.min.js')}}"></script>
<script src="{{asset('DataTables/js/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('DataTables/js/dataTables.bootstrap.min.js')}}"></script>
<script src="{{asset('js/custom.js')}}"></script>