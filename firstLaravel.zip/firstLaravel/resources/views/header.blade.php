<div class="header">
    <div class="container-fluid">
        <div class="navbar-header" style="">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                <span class="sr-only">Toggle navigation</span>
                <span class="glyphicon glyphicon-list"></span>
            </button>
            <a class="navbar-brand" href=""><img style="height: 60px; margin-top: -8px;" src="{{asset('images/incident-logo.png')}}"/></a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
            <ul id="top-menu" class="nav navbar-nav">
                <li>
                    <a href="{{url('/dash')}}"><span class="glyphicon glyphicon-home"></span>&nbsp;Home</a>
                </li>
               
                <li>
                    <a href="{{url('/logout')}}"  ><span class="glyphicon glyphicon-user"></span>&nbsp;Logout</a>
                </li>
                
            </ul>
        </div>
    </div>
</div>